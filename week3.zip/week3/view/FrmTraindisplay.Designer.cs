﻿namespace week3.view
{
    partial class FrmTraindisplay
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblCurrentStation = new Label();
            lblRailway = new Label();
            SuspendLayout();
            // 
            // lblCurrentStation
            // 
            lblCurrentStation.AutoSize = true;
            lblCurrentStation.Location = new Point(70, 73);
            lblCurrentStation.Name = "lblCurrentStation";
            lblCurrentStation.Size = new Size(113, 20);
            lblCurrentStation.TabIndex = 0;
            lblCurrentStation.Text = "Current station: ";
            // 
            // lblRailway
            // 
            lblRailway.AutoSize = true;
            lblRailway.Location = new Point(70, 118);
            lblRailway.Name = "lblRailway";
            lblRailway.Size = new Size(105, 20);
            lblRailway.TabIndex = 1;
            lblRailway.Text = "Railway Track: ";
            // 
            // ITraindisplay
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblRailway);
            Controls.Add(lblCurrentStation);
            Name = "ITraindisplay";
            Text = "ITraindisplay";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblCurrentStation;
        private Label lblRailway;
    }
}