﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using week3.controller;
using week3.model;

namespace week3.view
{
    public partial class FrmTraindisplay : Form, ITrainDisplay
    {
        private TrainJourney trainJourney;
        private TrainController trainController;

        public FrmTraindisplay(ITrainJourney trainJourney, IController controller)
        {
            this.trainDisplay = trainDisplay;
            ITrainJourney.Add(this);
        }
        public void Update(TrainStation trainStation)
        {
            if (trainStation == null)
            {
                lblCurrentStation.Text = "Geen station";
            }
            else
            {
                lblCurrentStation.Text = trainStation.Name;
            }
        }
    }
}
