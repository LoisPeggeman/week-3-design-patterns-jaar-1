﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using week3.model;

namespace week3.view
{
    public interface ITrainDisplay
    {
        void Update(TrainStation currentStation);
    }
}
