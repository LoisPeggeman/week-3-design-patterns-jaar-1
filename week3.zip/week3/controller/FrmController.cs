using System.Security.Cryptography.X509Certificates;
using week3.model;

namespace week3
{
    public partial class FrmController : Form, ITrainJourney
    {
        private void bttnNextStation_Click(object sender, EventArgs e)
        {
            stations.Next();

        }
    }
}
