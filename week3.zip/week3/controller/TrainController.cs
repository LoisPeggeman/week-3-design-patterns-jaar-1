﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace week3.controller
{
    public class TrainController : FrmController
    {
        private FrmController _Controller;

        public IController(FrmController controller)
        {
            _Controller = controller;
        }
        public void NextTrainStation()
        {
            _Controller.NextTrainStation();
        }
    }
}
