﻿namespace week3
{
    partial class FrmController
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            bttnNextStation = new Button();
            button2 = new Button();
            SuspendLayout();
            // 
            // bttnNextStation
            // 
            bttnNextStation.Location = new Point(170, 188);
            bttnNextStation.Name = "bttnNextStation";
            bttnNextStation.Size = new Size(260, 65);
            bttnNextStation.TabIndex = 0;
            bttnNextStation.Text = "Next Station";
            bttnNextStation.UseVisualStyleBackColor = true;
            bttnNextStation.Click += bttnNextStation_Click;
            // 
            // button2
            // 
            button2.Location = new Point(34, 383);
            button2.Name = "button2";
            button2.Size = new Size(94, 29);
            button2.TabIndex = 1;
            button2.Text = "New display";
            button2.UseVisualStyleBackColor = true;
            // 
            // IController
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button2);
            Controls.Add(bttnNextStation);
            Name = "IController";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Button bttnNextStation;
        private Button button2;
    }
}
