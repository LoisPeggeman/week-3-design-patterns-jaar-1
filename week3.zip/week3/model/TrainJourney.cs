﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using week3.view;

namespace week3.model
{
    internal class TrainJourney : ITrainJourney
    {
        private TrainStation currentStation;
        public TrainStation CurrentStation { get { return currentStation; } }


        private List<TrainStation> stations;
        private List<FrmTraindisplay> displays;

        public TrainJourney()
        {
            stations = new List<TrainStation>();
            CreateStations();

            currentStation = stations.First();

            displays = new List<FrmTraindisplay>();
        }
        

        public void Add(FrmTraindisplay traindisplay)
        {
            displays.Add(traindisplay);
        }
        public void NextStation()
        {
            TrainStation CurrentStation = currentStation;
            currentStation = stations.SkipWhile(x => x.StationId != currentStation.StationId).Skip(1).DefaultIfEmpty(stations[0]).FirstOrDefault();
            NotifyDisplays();
        }
        public void NotifyDisplays()
        {
            foreach(FrmTraindisplay tr in displays)
            {
                traindisplay.Update(currentStation);
            }
        }
    }
}
