﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace week3.model
{
    internal class TrainStation
    {
        private string name { get; set; }
        private int arrivalTrack { get; set; }
        private DateTime arrivalTime { get; set; }
        private DateTime departureTime { get; set; }

    }
}
