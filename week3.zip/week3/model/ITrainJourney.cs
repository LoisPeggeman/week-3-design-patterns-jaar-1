﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using week3.view;

namespace week3.model
{
    internal interface ITrainJourney
    {
        void NextStation();
        TrainStation CurrentStation {  get; }

        public void Add(FrmTraindisplay display);
        public void RemoveDisplay(FrmTraindisplay display);
}
